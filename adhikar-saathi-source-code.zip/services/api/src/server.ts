import cors from 'cors';
import dotenv from 'dotenv';
import express from 'express';
import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import morgan from 'morgan';
import { z } from 'zod';

dotenv.config();

const app = express();
const port = Number(process.env.PORT ?? 4000);
const jwtSecret = process.env.JWT_SECRET ?? 'phase-one-demo-secret';

type Report = z.infer<typeof reportSchema> & { id: string; createdAt: string; userId: string };
type Evidence = z.infer<typeof evidenceSchema> & { id: string; createdAt: string; userId: string };

const reportSchema = z.object({
  place: z.string().max(160).optional().default(''),
  description: z.string().min(1).max(4000),
  immediateDanger: z.boolean().default(false),
  consentToShare: z.boolean().default(false)
});

const evidenceSchema = z.object({
  label: z.string().min(1).max(160),
  kind: z.enum(['Photo', 'Audio', 'Message', 'Document', 'Other']),
  note: z.string().max(1200).optional().default('')
});

const reports: Report[] = [];
const evidence: Evidence[] = [];

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

function getUserId(authHeader?: string) {
  if (!authHeader?.startsWith('Bearer ')) {
    return 'guest';
  }
  try {
    const payload = jwt.verify(authHeader.slice(7), jwtSecret);
    return typeof payload === 'object' && 'sub' in payload ? String(payload.sub) : 'guest';
  } catch {
    return 'guest';
  }
}

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'adhikaar-saathi-api', phase: 1 });
});

app.post('/auth/guest', (_req, res) => {
  const token = jwt.sign({ sub: `guest-${Date.now()}`, mode: 'guest' }, jwtSecret, { expiresIn: '12h' });
  res.json({ token, mode: 'guest', notificationPreviewPolicy: 'generic-only' });
});

app.get('/legal/rights', (req, res) => {
  const language = req.query.language === 'hi' ? 'hi' : 'en';
  const rights = language === 'hi'
    ? [
        'आप सुरक्षा आदेश मांग सकती हैं।',
        'आप साझा घर में रहने का अधिकार रखती हैं।',
        'आप मुफ्त कानूनी सहायता मांग सकती हैं।'
      ]
    : [
        'You can ask for a protection order.',
        'You have a right to stay in the shared household.',
        'You can ask for free legal aid.'
      ];
  res.json({ language, rights });
});

app.get('/directory/help', (_req, res) => {
  res.json({
    results: [
      { name: 'Emergency Response Support System', type: 'Emergency', phone: '112' },
      { name: 'Women Helpline', type: 'Helpline', phone: '181' },
      { name: 'Police Women Helpline', type: 'Police', phone: '1091' }
    ]
  });
});

app.post('/reports', (req, res) => {
  const parsed = reportSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid report', details: parsed.error.flatten() });
    return;
  }
  const report: Report = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    userId: getUserId(req.header('authorization')),
    ...parsed.data
  };
  reports.push(report);
  res.status(201).json({ report });
});

app.get('/reports', (req, res) => {
  const userId = getUserId(req.header('authorization'));
  res.json({ reports: reports.filter((report) => report.userId === userId) });
});

app.post('/evidence', (req, res) => {
  const parsed = evidenceSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Invalid evidence', details: parsed.error.flatten() });
    return;
  }
  const item: Evidence = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    userId: getUserId(req.header('authorization')),
    ...parsed.data
  };
  evidence.push(item);
  res.status(201).json({ evidence: item, upload: { phase: 2, status: 'encrypted-object-storage-not-enabled' } });
});

app.get('/guidance/triage', (_req, res) => {
  res.json({
    steps: [
      'If there is immediate danger, call 112 first.',
      'Move to a safer place before collecting details.',
      'Save medical slips, messages, photos, and witness names.',
      'Contact 181, 1091, or local legal aid when it is safe.'
    ],
    disclaimer: 'This app is not a replacement for emergency services, legal counsel, or medical care.'
  });
});

app.listen(port, () => {
  console.log(`Adhikaar Saathi API listening on http://localhost:${port}`);
});
