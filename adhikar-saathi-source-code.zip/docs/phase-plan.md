# 24-Week Capstone Phase Plan

## Phase 1: Weeks 1-12

Goal: a working, demoable Android-first MVP that can be shown safely without real victim data.

1. Requirements, threat model, and privacy rules.
2. React Native navigation, guest mode, language switch, and Quick Exit.
3. App-lock gate for reports, evidence, and guidance.
4. Plain-language rights library in English and Hindi.
5. Local-first incident report flow.
6. Evidence vault metadata flow.
7. Mock nearby help directory.
8. Scripted 24/7 guidance triage.
9. Express REST API skeleton and route contracts.
10. Usability testing with safety scenarios.
11. Android build and demo prep.
12. Report, presentation, and Phase 2 backlog.

## Phase 2: Weeks 13-24

Goal: replace demo-only pieces with hardened integrations and supervised intelligence.

1. PostgreSQL schema, migrations, Redis sessions/cache.
2. JWT/Firebase Auth hardening and OAuth.
3. Encrypted S3-compatible evidence storage.
4. Google Maps location search and provider ranking.
5. RAG chatbot over verified legal and service-provider content.
6. OCR and metadata extraction for evidence.
7. ML-assisted risk assessment with human-readable explanations.
8. Admin/provider web companion.
9. NGO/legal aid/police integration workflows.
10. Security review, accessibility pass, and deployment automation.

## Practical AI Note

Do not start Phase 2 with a fine-tuned legal model. A safer capstone path is retrieval augmented generation over a small verified knowledge base, with strict disclaimers, emergency escalation, and source citations. Fine-tuning can make wrong legal advice sound more confident, while RAG lets the team update sources and audit answers.
