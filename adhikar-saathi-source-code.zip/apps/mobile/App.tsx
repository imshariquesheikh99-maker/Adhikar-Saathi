import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  BackHandler,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator, NativeStackNavigationProp } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

type Language =
  | 'en'
  | 'hi'
  | 'bn'
  | 'te'
  | 'mr'
  | 'ta'
  | 'ur'
  | 'gu'
  | 'kn'
  | 'ml'
  | 'or'
  | 'pa'
  | 'as'
  | 'mai'
  | 'sat'
  | 'ks'
  | 'ne'
  | 'kok'
  | 'sd'
  | 'doi'
  | 'mni'
  | 'sa';
type RootStackParamList = {
  Onboarding: undefined;
  Main: undefined;
  Neutral: undefined;
  Locked: { next: keyof MainTabParamList };
};
type MainTabParamList = {
  Home: undefined;
  Rights: undefined;
  Report: undefined;
  Evidence: undefined;
  Help: undefined;
  Guidance: undefined;
  Settings: undefined;
};

type ReportRecord = {
  id: string;
  date: string;
  place: string;
  description: string;
  immediateDanger: boolean;
  consentToShare: boolean;
};

type EvidenceRecord = {
  id: string;
  label: string;
  kind: string;
  note: string;
  createdAt: string;
};

type RightsItem = {
  title: string;
  body: string;
};

const RootStack = createNativeStackNavigator<RootStackParamList>();
const Tabs = createBottomTabNavigator<MainTabParamList>();

const palette = {
  ink: '#18212F',
  muted: '#647084',
  paper: '#F5F7FB',
  panel: '#FFFFFF',
  line: '#DEE5EF',
  teal: '#087A7D',
  tealDark: '#075E61',
  rose: '#C23A5B',
  saffron: '#D99025',
  green: '#287B58',
  indigo: '#4056A1',
  softTeal: '#E4F6F4',
  softRose: '#FFF0F4',
  softAmber: '#FFF6E8'
};

type AppCopy = {
  appName: string;
  strapline: string;
  guest: string;
  createPin: string;
  quickExit: string;
  unlock: string;
  pin: string;
  useBiometric: string;
  home: string;
  rights: string;
  report: string;
  evidence: string;
  help: string;
  guidance: string;
  settings: string;
  danger: string;
  phase: string;
  neutral: string;
};

const languageOptions: Array<{ code: Language; nativeName: string; englishName: string }> = [
  { code: 'en', nativeName: 'English', englishName: 'English' },
  { code: 'hi', nativeName: 'हिंदी', englishName: 'Hindi' },
  { code: 'bn', nativeName: 'বাংলা', englishName: 'Bengali' },
  { code: 'te', nativeName: 'తెలుగు', englishName: 'Telugu' },
  { code: 'mr', nativeName: 'मराठी', englishName: 'Marathi' },
  { code: 'ta', nativeName: 'தமிழ்', englishName: 'Tamil' },
  { code: 'ur', nativeName: 'اردو', englishName: 'Urdu' },
  { code: 'gu', nativeName: 'ગુજરાતી', englishName: 'Gujarati' },
  { code: 'kn', nativeName: 'ಕನ್ನಡ', englishName: 'Kannada' },
  { code: 'ml', nativeName: 'മലയാളം', englishName: 'Malayalam' },
  { code: 'or', nativeName: 'ଓଡ଼ିଆ', englishName: 'Odia' },
  { code: 'pa', nativeName: 'ਪੰਜਾਬੀ', englishName: 'Punjabi' },
  { code: 'as', nativeName: 'অসমীয়া', englishName: 'Assamese' },
  { code: 'mai', nativeName: 'मैथिली', englishName: 'Maithili' },
  { code: 'sat', nativeName: 'ᱥᱟᱱᱛᱟᱲᱤ', englishName: 'Santali' },
  { code: 'ks', nativeName: 'کٲشُر', englishName: 'Kashmiri' },
  { code: 'ne', nativeName: 'नेपाली', englishName: 'Nepali' },
  { code: 'kok', nativeName: 'कोंकणी', englishName: 'Konkani' },
  { code: 'sd', nativeName: 'سنڌي', englishName: 'Sindhi' },
  { code: 'doi', nativeName: 'डोगरी', englishName: 'Dogri' },
  { code: 'mni', nativeName: 'মৈতৈলোন্', englishName: 'Manipuri' },
  { code: 'sa', nativeName: 'संस्कृतम्', englishName: 'Sanskrit' }
];

function isLanguage(value: string | null): value is Language {
  return languageOptions.some((option) => option.code === value);
}

type IconName =
  | 'add-circle-outline'
  | 'alert-circle'
  | 'book-outline'
  | 'call'
  | 'chatbubbles-outline'
  | 'document-text-outline'
  | 'exit-outline'
  | 'finger-print-outline'
  | 'folder-open-outline'
  | 'home-outline'
  | 'key-outline'
  | 'location-outline'
  | 'lock-closed-outline'
  | 'person-outline'
  | 'save-outline'
  | 'settings-outline'
  | 'shield-checkmark';

function AppIcon({ name, size, color }: { name: IconName; size: number; color: string }) {
  const symbols: Record<IconName, string> = {
    'add-circle-outline': '+',
    'alert-circle': '!',
    'book-outline': '§',
    call: '☎',
    'chatbubbles-outline': '?',
    'document-text-outline': '✎',
    'exit-outline': 'X',
    'finger-print-outline': '◉',
    'folder-open-outline': '◫',
    'home-outline': '⌂',
    'key-outline': '◇',
    'location-outline': '⌖',
    'lock-closed-outline': '●',
    'person-outline': '◯',
    'save-outline': '✓',
    'settings-outline': '⚙',
    'shield-checkmark': '✓'
  };
  const boxSize = Math.max(size + 12, 30);
  const tint = color === '#FFFFFF' ? 'rgba(255,255,255,0.18)' : palette.softTeal;
  return (
    <View style={[styles.iconBadge, { width: boxSize, height: boxSize, backgroundColor: tint }]}>
      <Text style={{ color, fontSize: Math.max(size - 2, 14), fontWeight: '900', lineHeight: Math.max(size, 16) }}>{symbols[name]}</Text>
    </View>
  );
}

const copy: Record<Language, AppCopy> = {
  en: {
    appName: 'Adhikaar Saathi',
    strapline: 'Rights, safety notes, and help without forcing you to sign in.',
    guest: 'Continue as guest',
    createPin: 'Create app PIN',
    quickExit: 'Quick Exit',
    unlock: 'Unlock protected area',
    pin: 'PIN',
    useBiometric: 'Try biometric unlock',
    home: 'Safety home',
    rights: 'Rights',
    report: 'Report',
    evidence: 'Evidence',
    help: 'Help',
    guidance: 'Guidance',
    settings: 'Settings',
    danger: 'If you are in immediate danger, call 112 or move to a safer place first.',
    phase: 'Phase 1 MVP: local-first, anonymous, and safe for demos.',
    neutral: 'Calculator'
  },
  hi: {
    appName: 'अधिकार साथी',
    strapline: 'बिना साइन इन किए अधिकार, सुरक्षा नोट्स और मदद।',
    guest: 'गेस्ट के रूप में जारी रखें',
    createPin: 'ऐप PIN बनाएं',
    quickExit: 'तुरंत बाहर',
    unlock: 'सुरक्षित भाग खोलें',
    pin: 'PIN',
    useBiometric: 'बायोमेट्रिक से खोलें',
    home: 'सुरक्षा होम',
    rights: 'अधिकार',
    report: 'रिपोर्ट',
    evidence: 'सबूत',
    help: 'मदद',
    guidance: 'मार्गदर्शन',
    settings: 'सेटिंग',
    danger: 'अगर तुरंत खतरा है, पहले 112 पर कॉल करें या सुरक्षित जगह जाएं।',
    phase: 'फेज 1 MVP: लोकल-फर्स्ट, गुमनाम और डेमो के लिए सुरक्षित।',
    neutral: 'कैलकुलेटर'
  },
  bn: {
    appName: 'অধিকার সাথী',
    strapline: 'সাইন ইন ছাড়াই অধিকার, নিরাপত্তা নোট এবং সাহায্য।',
    guest: 'অতিথি হিসেবে চালিয়ে যান',
    createPin: 'অ্যাপ PIN তৈরি করুন',
    quickExit: 'দ্রুত বের হন',
    unlock: 'সুরক্ষিত অংশ খুলুন',
    pin: 'PIN',
    useBiometric: 'বায়োমেট্রিক দিয়ে খুলুন',
    home: 'নিরাপত্তা হোম',
    rights: 'অধিকার',
    report: 'রিপোর্ট',
    evidence: 'প্রমাণ',
    help: 'সাহায্য',
    guidance: 'নির্দেশনা',
    settings: 'সেটিংস',
    danger: 'তাৎক্ষণিক বিপদে থাকলে আগে 112-এ কল করুন বা নিরাপদ স্থানে যান।',
    phase: 'ফেজ 1 MVP: লোকাল-ফার্স্ট, গোপনীয় এবং ডেমোর জন্য নিরাপদ।',
    neutral: 'ক্যালকুলেটর'
  },
  te: {
    appName: 'అధికార సాథి',
    strapline: 'సైన్ ఇన్ లేకుండా హక్కులు, భద్రతా నోట్లు మరియు సహాయం.',
    guest: 'అతిథిగా కొనసాగండి',
    createPin: 'యాప్ PIN సృష్టించండి',
    quickExit: 'త్వరగా బయటకు',
    unlock: 'రక్షిత భాగాన్ని తెరవండి',
    pin: 'PIN',
    useBiometric: 'బయోమెట్రిక్‌తో తెరవండి',
    home: 'భద్రత హోమ్',
    rights: 'హక్కులు',
    report: 'రిపోర్ట్',
    evidence: 'సాక్ష్యం',
    help: 'సహాయం',
    guidance: 'మార్గదర్శనం',
    settings: 'సెట్టింగ్స్',
    danger: 'తక్షణ ప్రమాదంలో ఉంటే ముందుగా 112కి కాల్ చేయండి లేదా సురక్షిత స్థలానికి వెళ్లండి.',
    phase: 'దశ 1 MVP: లోకల్-ఫస్ట్, అనామక, డెమోకు సురక్షితం.',
    neutral: 'కాలిక్యులేటర్'
  },
  mr: {
    appName: 'अधिकार साथी',
    strapline: 'साइन इन न करता अधिकार, सुरक्षा नोंदी आणि मदत.',
    guest: 'गेस्ट म्हणून पुढे जा',
    createPin: 'अॅप PIN तयार करा',
    quickExit: 'त्वरित बाहेर',
    unlock: 'सुरक्षित भाग उघडा',
    pin: 'PIN',
    useBiometric: 'बायोमेट्रिकने उघडा',
    home: 'सुरक्षा होम',
    rights: 'अधिकार',
    report: 'रिपोर्ट',
    evidence: 'पुरावा',
    help: 'मदत',
    guidance: 'मार्गदर्शन',
    settings: 'सेटिंग्स',
    danger: 'तत्काळ धोका असल्यास आधी 112 वर कॉल करा किंवा सुरक्षित ठिकाणी जा.',
    phase: 'फेज 1 MVP: लोकल-फर्स्ट, गुप्त आणि डेमोसाठी सुरक्षित.',
    neutral: 'कॅल्क्युलेटर'
  },
  ta: {
    appName: 'அதிகார் சாத்தி',
    strapline: 'உள்நுழையாமல் உரிமைகள், பாதுகாப்பு குறிப்புகள் மற்றும் உதவி.',
    guest: 'விருந்தினராக தொடரவும்',
    createPin: 'ஆப் PIN உருவாக்கவும்',
    quickExit: 'விரைவாக வெளியேறு',
    unlock: 'பாதுகாக்கப்பட்ட பகுதியைத் திறக்கவும்',
    pin: 'PIN',
    useBiometric: 'பயோமெட்ரிக் திறப்பு',
    home: 'பாதுகாப்பு முகப்பு',
    rights: 'உரிமைகள்',
    report: 'அறிக்கை',
    evidence: 'ஆதாரம்',
    help: 'உதவி',
    guidance: 'வழிகாட்டல்',
    settings: 'அமைப்புகள்',
    danger: 'உடனடி ஆபத்து இருந்தால் முதலில் 112 அழைக்கவும் அல்லது பாதுகாப்பான இடத்துக்குச் செல்லவும்.',
    phase: 'கட்டம் 1 MVP: உள்ளூர்-முதல், பெயரில்லா, டெமோக்கு பாதுகாப்பானது.',
    neutral: 'கால்குலேட்டர்'
  },
  ur: {
    appName: 'ادھیکار ساتھی',
    strapline: 'سائن اِن کے بغیر حقوق، حفاظتی نوٹس اور مدد۔',
    guest: 'مہمان کے طور پر جاری رکھیں',
    createPin: 'ایپ PIN بنائیں',
    quickExit: 'فوری خروج',
    unlock: 'محفوظ حصہ کھولیں',
    pin: 'PIN',
    useBiometric: 'بایومیٹرک سے کھولیں',
    home: 'حفاظتی ہوم',
    rights: 'حقوق',
    report: 'رپورٹ',
    evidence: 'ثبوت',
    help: 'مدد',
    guidance: 'رہنمائی',
    settings: 'سیٹنگز',
    danger: 'اگر فوری خطرہ ہو تو پہلے 112 پر کال کریں یا محفوظ جگہ جائیں۔',
    phase: 'فیز 1 MVP: مقامی، گمنام، اور ڈیمو کے لیے محفوظ۔',
    neutral: 'کیلکولیٹر'
  },
  gu: {
    appName: 'અધિકાર સાથી',
    strapline: 'સાઇન ઇન વિના અધિકાર, સુરક્ષા નોંધો અને મદદ.',
    guest: 'ગેસ્ટ તરીકે ચાલુ રાખો',
    createPin: 'એપ PIN બનાવો',
    quickExit: 'ઝડપી બહાર નીકળો',
    unlock: 'સુરક્ષિત ભાગ ખોલો',
    pin: 'PIN',
    useBiometric: 'બાયોમેટ્રિકથી ખોલો',
    home: 'સુરક્ષા હોમ',
    rights: 'અધિકાર',
    report: 'રિપોર્ટ',
    evidence: 'પુરાવો',
    help: 'મદદ',
    guidance: 'માર્ગદર્શન',
    settings: 'સેટિંગ્સ',
    danger: 'તાત્કાલિક જોખમ હોય તો પહેલા 112 પર કૉલ કરો અથવા સુરક્ષિત જગ્યાએ જાઓ.',
    phase: 'ફેઝ 1 MVP: લોકલ-ફર્સ્ટ, અનામિક અને ડેમો માટે સુરક્ષિત.',
    neutral: 'કેલ્ક્યુલેટર'
  },
  kn: {
    appName: 'ಅಧಿಕಾರ ಸಾಥಿ',
    strapline: 'ಸೈನ್ ಇನ್ ಇಲ್ಲದೆ ಹಕ್ಕುಗಳು, ಸುರಕ್ಷತಾ ಟಿಪ್ಪಣಿಗಳು ಮತ್ತು ಸಹಾಯ.',
    guest: 'ಅತಿಥಿಯಾಗಿ ಮುಂದುವರಿಸಿ',
    createPin: 'ಆಪ್ PIN ರಚಿಸಿ',
    quickExit: 'ತ್ವರಿತ ನಿರ್ಗಮನ',
    unlock: 'ರಕ್ಷಿತ ಭಾಗ ತೆರೆಯಿರಿ',
    pin: 'PIN',
    useBiometric: 'ಬಯೋಮೆಟ್ರಿಕ್ ತೆರೆಯಿರಿ',
    home: 'ಸುರಕ್ಷತಾ ಹೋಮ್',
    rights: 'ಹಕ್ಕುಗಳು',
    report: 'ರಿಪೋರ್ಟ್',
    evidence: 'ಸಾಕ್ಷ್ಯ',
    help: 'ಸಹಾಯ',
    guidance: 'ಮಾರ್ಗದರ್ಶನ',
    settings: 'ಸೆಟ್ಟಿಂಗ್ಸ್',
    danger: 'ತಕ್ಷಣದ ಅಪಾಯದಲ್ಲಿದ್ದರೆ ಮೊದಲು 112ಕ್ಕೆ ಕರೆ ಮಾಡಿ ಅಥವಾ ಸುರಕ್ಷಿತ ಸ್ಥಳಕ್ಕೆ ಹೋಗಿ.',
    phase: 'ಹಂತ 1 MVP: ಸ್ಥಳೀಯ-ಮೊದಲು, ಅನಾಮಧೇಯ, ಡೆಮೊಗೆ ಸುರಕ್ಷಿತ.',
    neutral: 'ಕ್ಯಾಲ್ಕುಲೇಟರ್'
  },
  ml: {
    appName: 'അധികാർ സാഥി',
    strapline: 'സൈൻ ഇൻ ഇല്ലാതെ അവകാശങ്ങൾ, സുരക്ഷാ കുറിപ്പുകൾ, സഹായം.',
    guest: 'അതിഥിയായി തുടരുക',
    createPin: 'ആപ്പ് PIN സൃഷ്ടിക്കുക',
    quickExit: 'വേഗം പുറത്തുകടക്കുക',
    unlock: 'സംരക്ഷിത ഭാഗം തുറക്കുക',
    pin: 'PIN',
    useBiometric: 'ബയോമെട്രിക് ഉപയോഗിച്ച് തുറക്കുക',
    home: 'സുരക്ഷാ ഹോം',
    rights: 'അവകാശങ്ങൾ',
    report: 'റിപ്പോർട്ട്',
    evidence: 'തെളിവ്',
    help: 'സഹായം',
    guidance: 'മാർഗ്ഗനിർദ്ദേശം',
    settings: 'സെറ്റിംഗ്സ്',
    danger: 'ഉടൻ അപകടമുണ്ടെങ്കിൽ ആദ്യം 112 വിളിക്കുക അല്ലെങ്കിൽ സുരക്ഷിത സ്ഥലത്തേക്ക് പോകുക.',
    phase: 'ഘട്ടം 1 MVP: ലോക്കൽ-ഫസ്റ്റ്, അനാമികം, ഡെമോയ്ക്ക് സുരക്ഷിതം.',
    neutral: 'കാൽക്കുലേറ്റർ'
  },
  or: {
    appName: 'ଅଧିକାର ସାଥୀ',
    strapline: 'ସାଇନ୍ ଇନ୍ ବିନା ଅଧିକାର, ସୁରକ୍ଷା ଟିପ୍ପଣୀ ଓ ସାହାଯ୍ୟ।',
    guest: 'ଗେଷ୍ଟ ଭାବେ ଚାଲୁ ରଖନ୍ତୁ',
    createPin: 'ଆପ୍ PIN ତିଆରି କରନ୍ତୁ',
    quickExit: 'ତୁରନ୍ତ ବାହାର',
    unlock: 'ସୁରକ୍ଷିତ ଭାଗ ଖୋଲନ୍ତୁ',
    pin: 'PIN',
    useBiometric: 'ବାୟୋମେଟ୍ରିକ୍ ଦ୍ୱାରା ଖୋଲନ୍ତୁ',
    home: 'ସୁରକ୍ଷା ହୋମ୍',
    rights: 'ଅଧିକାର',
    report: 'ରିପୋର୍ଟ',
    evidence: 'ପ୍ରମାଣ',
    help: 'ସାହାଯ୍ୟ',
    guidance: 'ମାର୍ଗଦର୍ଶନ',
    settings: 'ସେଟିଂସ୍',
    danger: 'ତୁରନ୍ତ ବିପଦ ଥିଲେ ପ୍ରଥମେ 112କୁ କଲ୍ କରନ୍ତୁ କିମ୍ବା ସୁରକ୍ଷିତ ଜାଗାକୁ ଯାଆନ୍ତୁ।',
    phase: 'ଫେଜ୍ 1 MVP: ଲୋକାଲ୍-ଫର୍ଷ୍ଟ, ଅନାମିକ, ଡେମୋ ପାଇଁ ସୁରକ୍ଷିତ।',
    neutral: 'କ୍ୟାଲ୍କୁଲେଟର'
  },
  pa: {
    appName: 'ਅਧਿਕਾਰ ਸਾਥੀ',
    strapline: 'ਸਾਈਨ ਇਨ ਤੋਂ ਬਿਨਾਂ ਹੱਕ, ਸੁਰੱਖਿਆ ਨੋਟ ਅਤੇ ਮਦਦ।',
    guest: 'ਮਹਿਮਾਨ ਵਜੋਂ ਜਾਰੀ ਰੱਖੋ',
    createPin: 'ਐਪ PIN ਬਣਾਓ',
    quickExit: 'ਤੁਰੰਤ ਬਾਹਰ',
    unlock: 'ਸੁਰੱਖਿਅਤ ਹਿੱਸਾ ਖੋਲ੍ਹੋ',
    pin: 'PIN',
    useBiometric: 'ਬਾਇਓਮੈਟਰਿਕ ਨਾਲ ਖੋਲ੍ਹੋ',
    home: 'ਸੁਰੱਖਿਆ ਹੋਮ',
    rights: 'ਹੱਕ',
    report: 'ਰਿਪੋਰਟ',
    evidence: 'ਸਬੂਤ',
    help: 'ਮਦਦ',
    guidance: 'ਮਾਰਗਦਰਸ਼ਨ',
    settings: 'ਸੈਟਿੰਗਜ਼',
    danger: 'ਤੁਰੰਤ ਖਤਰਾ ਹੋਵੇ ਤਾਂ ਪਹਿਲਾਂ 112 ਤੇ ਕਾਲ ਕਰੋ ਜਾਂ ਸੁਰੱਖਿਅਤ ਥਾਂ ਜਾਓ।',
    phase: 'ਫੇਜ਼ 1 MVP: ਲੋਕਲ-ਫਰਸਟ, ਗੁਮਨਾਮ, ਡੇਮੋ ਲਈ ਸੁਰੱਖਿਅਤ।',
    neutral: 'ਕੈਲਕੁਲੇਟਰ'
  },
  as: {
    appName: 'অধিকাৰ সাথী',
    strapline: 'ছাইন ইন নকৰাকৈ অধিকাৰ, সুৰক্ষা টোকা আৰু সহায়।',
    guest: 'অতিথি হিচাপে আগবাঢ়ক',
    createPin: 'এপ PIN বনাওক',
    quickExit: 'দ্ৰুত বাহিৰ',
    unlock: 'সুৰক্ষিত অংশ খোলক',
    pin: 'PIN',
    useBiometric: 'বায়োমেট্ৰিকেৰে খোলক',
    home: 'সুৰক্ষা হোম',
    rights: 'অধিকাৰ',
    report: 'ৰিপোৰ্ট',
    evidence: 'প্ৰমাণ',
    help: 'সহায়',
    guidance: 'নিৰ্দেশনা',
    settings: 'ছেটিংছ',
    danger: 'তাৎক্ষণিক বিপদ থাকিলে প্ৰথমে 112 লৈ ফোন কৰক বা সুৰক্ষিত ঠাইলৈ যাওক।',
    phase: 'ফেজ 1 MVP: লোকেল-ফাৰ্ষ্ট, নামবিহীন, ডেমোৰ বাবে সুৰক্ষিত।',
    neutral: 'কেলকুলেটৰ'
  },
  mai: {
    appName: 'अधिकार साथी',
    strapline: 'साइन इन बिना अधिकार, सुरक्षा नोट आ मदद।',
    guest: 'गेस्ट केर रूप मे आगू बढ़ू',
    createPin: 'ऐप PIN बनाउ',
    quickExit: 'तुरंत बाहर',
    unlock: 'सुरक्षित भाग खोलू',
    pin: 'PIN',
    useBiometric: 'बायोमेट्रिक सँ खोलू',
    home: 'सुरक्षा होम',
    rights: 'अधिकार',
    report: 'रिपोर्ट',
    evidence: 'सबूत',
    help: 'मदद',
    guidance: 'मार्गदर्शन',
    settings: 'सेटिंग',
    danger: 'तुरंत खतरा हो त पहिने 112 पर कॉल करू वा सुरक्षित जगह जाउ।',
    phase: 'फेज 1 MVP: लोकल-फर्स्ट, गुमनाम आ डेमो लेल सुरक्षित।',
    neutral: 'कैलकुलेटर'
  },
  sat: {
    appName: 'Adhikaar Saathi',
    strapline: 'Sign in bako, rights, safety notes ar help.',
    guest: 'Guest leka calak',
    createPin: 'App PIN benao',
    quickExit: 'Quick Exit',
    unlock: 'Protected area khol',
    pin: 'PIN',
    useBiometric: 'Biometric unlock',
    home: 'Safety home',
    rights: 'Rights',
    report: 'Report',
    evidence: 'Evidence',
    help: 'Help',
    guidance: 'Guidance',
    settings: 'Settings',
    danger: 'Jodi turanta bipod men, age 112 call me na safe jagah te calak.',
    phase: 'Phase 1 MVP: local-first, anonymous, demo safe.',
    neutral: 'Calculator'
  },
  ks: {
    appName: 'ادھیکار ساتھی',
    strapline: 'سائن اِن بغیر حقوق، حفاظت نوٹ تہ مدد۔',
    guest: 'مہمان طور جاری',
    createPin: 'ایپ PIN بناو',
    quickExit: 'فوری باہر',
    unlock: 'محفوظ حصہ کھولو',
    pin: 'PIN',
    useBiometric: 'بایومیٹرک کھولو',
    home: 'حفاظت ہوم',
    rights: 'حقوق',
    report: 'رپورٹ',
    evidence: 'ثبوت',
    help: 'مدد',
    guidance: 'رہنمائی',
    settings: 'سیٹنگز',
    danger: 'اگر فوری خطرہ ہو، پہلے 112 کال کرو یا محفوظ جگہ جاو۔',
    phase: 'فیز 1 MVP: لوکل-فرسٹ، گمنام، ڈیمو محفوظ۔',
    neutral: 'کیلکولیٹر'
  },
  ne: {
    appName: 'अधिकार साथी',
    strapline: 'साइन इन नगरी अधिकार, सुरक्षा नोट र सहयोग।',
    guest: 'अतिथिका रूपमा जारी राख्नुहोस्',
    createPin: 'एप PIN बनाउनुहोस्',
    quickExit: 'छिटो बाहिर',
    unlock: 'सुरक्षित भाग खोल्नुहोस्',
    pin: 'PIN',
    useBiometric: 'बायोमेट्रिकले खोल्नुहोस्',
    home: 'सुरक्षा होम',
    rights: 'अधिकार',
    report: 'रिपोर्ट',
    evidence: 'प्रमाण',
    help: 'सहयोग',
    guidance: 'मार्गदर्शन',
    settings: 'सेटिङ्स',
    danger: 'तत्काल खतरा भए पहिले 112 मा कल गर्नुहोस् वा सुरक्षित ठाउँ जानुहोस्।',
    phase: 'फेज 1 MVP: लोकल-फर्स्ट, अनामिक, डेमोका लागि सुरक्षित।',
    neutral: 'क्याल्कुलेटर'
  },
  kok: {
    appName: 'अधिकार साथी',
    strapline: 'साइन इन न करता अधिकार, सुरक्षेची नोंद आनी मदत.',
    guest: 'गेस्ट म्हण पुढें वचात',
    createPin: 'अॅप PIN तयार करात',
    quickExit: 'बेगीन भायर',
    unlock: 'सुरक्षित भाग उगडात',
    pin: 'PIN',
    useBiometric: 'बायोमेट्रिकान उगडात',
    home: 'सुरक्षा होम',
    rights: 'अधिकार',
    report: 'रिपोर्ट',
    evidence: 'पुरावो',
    help: 'मदत',
    guidance: 'मार्गदर्शन',
    settings: 'सेटिंग्स',
    danger: 'तुरत धोको आसल्यार पयलीं 112 कॉल करात वा सुरक्षित सुवातेर वचात.',
    phase: 'फेज 1 MVP: लोकल-फर्स्ट, अनामिक, डेमो खातीर सुरक्षित.',
    neutral: 'कॅल्क्युलेटर'
  },
  sd: {
    appName: 'ادھیکار ساٿي',
    strapline: 'سائن اِن کانسواءِ حق، حفاظت نوٽس ۽ مدد.',
    guest: 'مهمان طور جاري رکو',
    createPin: 'ايپ PIN ٺاهيو',
    quickExit: 'جلدي ٻاهر',
    unlock: 'محفوظ حصو کوليو',
    pin: 'PIN',
    useBiometric: 'بائيو ميٽرڪ سان کوليو',
    home: 'حفاظت هوم',
    rights: 'حق',
    report: 'رپورٽ',
    evidence: 'ثبوت',
    help: 'مدد',
    guidance: 'رهنمائي',
    settings: 'سيٽنگز',
    danger: 'جيڪڏهن فوري خطرو هجي ته پهرين 112 تي ڪال ڪريو يا محفوظ هنڌ وڃو.',
    phase: 'فيز 1 MVP: لوڪل-فرسٽ، گمنام، ڊيمو لاءِ محفوظ.',
    neutral: 'ڪيلڪيوليٽر'
  },
  doi: {
    appName: 'अधिकार साथी',
    strapline: 'साइन इन बिना अधिकार, सुरक्षा नोट ते मदद।',
    guest: 'गेस्ट दे रूप च जारी रखो',
    createPin: 'ऐप PIN बनाओ',
    quickExit: 'तुरंत बाहर',
    unlock: 'सुरक्षित हिस्सा खोलो',
    pin: 'PIN',
    useBiometric: 'बायोमेट्रिक नाल खोलो',
    home: 'सुरक्षा होम',
    rights: 'अधिकार',
    report: 'रिपोर्ट',
    evidence: 'सबूत',
    help: 'मदद',
    guidance: 'मार्गदर्शन',
    settings: 'सेटिंग्स',
    danger: 'जे तुरंत खतरा ऐ तां पैहले 112 पर कॉल करो या सुरक्षित थाहर जाओ।',
    phase: 'फेज 1 MVP: लोकल-फर्स्ट, गुमनाम, डेमो लेई सुरक्षित।',
    neutral: 'कैलकुलेटर'
  },
  mni: {
    appName: 'অধিকার সাথী',
    strapline: 'সাইন ইন তৌদনা হক, সেফটি নোট অমসুং মতেং।',
    guest: 'গেস্ট ওইনা মখা চৎথরকউ',
    createPin: 'এপ PIN শেম্মু',
    quickExit: 'খুদক্তা থোকপা',
    unlock: 'সুরক্ষিত শরুক হাংদোকউ',
    pin: 'PIN',
    useBiometric: 'বায়োমেট্রিকনা হাংদোকউ',
    home: 'সেফটি হোম',
    rights: 'হক',
    report: 'রিপোর্ট',
    evidence: 'প্রমাণ',
    help: 'মতেং',
    guidance: 'লাইনিং',
    settings: 'সেটিংস',
    danger: 'খুদক্তা খুদোংচাবা লৈরবদি অহানবদা 112 দা কল তৌবিয়ু নত্রগা সেফ ওইবা মফমদা চৎলু।',
    phase: 'ফেজ 1 MVP: লোকল-ফার্স্ট, অনোনিমস, ডেমোগী সেফ।',
    neutral: 'ক্যালকুলেটর'
  },
  sa: {
    appName: 'अधिकारसाथी',
    strapline: 'प्रवेशं विना अधिकाराः, सुरक्षा-सूचनाः, सहायता च।',
    guest: 'अतिथिरूपेण अनुवर्तस्व',
    createPin: 'अनुप्रयोगस्य PIN रचय',
    quickExit: 'शीघ्रनिर्गमनम्',
    unlock: 'रक्षितं भागं उद्घाटय',
    pin: 'PIN',
    useBiometric: 'जैवमानेन उद्घाटय',
    home: 'सुरक्षा-गृहम्',
    rights: 'अधिकाराः',
    report: 'प्रतिवेदनम्',
    evidence: 'प्रमाणम्',
    help: 'सहायता',
    guidance: 'मार्गदर्शनम्',
    settings: 'विन्यासाः',
    danger: 'यदि सद्यः संकटम् अस्ति, प्रथमं 112 आह्वयतु अथवा सुरक्षितं स्थानं गच्छतु।',
    phase: 'प्रथमः चरणः MVP: स्थानीय-प्रथमः, अनामिकः, प्रदर्शनाय सुरक्षितः।',
    neutral: 'गणकयन्त्रम्'
  }
};

const rightsContent: Partial<Record<Language, RightsItem[]>> = {
  en: [
    {
      title: 'You can ask for protection',
      body: 'Under the Protection of Women from Domestic Violence Act, you can ask a court for a protection order to stop violence, threats, contact, or entry into your safe place.'
    },
    {
      title: 'You can stay in the shared home',
      body: 'You do not have to leave the shared household only because you reported abuse. A court can pass a residence order.'
    },
    {
      title: 'You can seek money support',
      body: 'You may ask for medical costs, lost earnings, child support, and maintenance. Keep bills, photos, and messages safely.'
    },
    {
      title: 'You can get free legal help',
      body: 'District Legal Services Authorities and women helplines can connect you to free legal aid.'
    }
  ],
  hi: [
    {
      title: 'आप सुरक्षा मांग सकती हैं',
      body: 'घरेलू हिंसा अधिनियम के तहत अदालत से सुरक्षा आदेश मांगा जा सकता है ताकि हिंसा, धमकी, संपर्क या सुरक्षित जगह में प्रवेश रोका जा सके।'
    },
    {
      title: 'आप साझा घर में रह सकती हैं',
      body: 'हिंसा की रिपोर्ट करने से आपको साझा घर छोड़ना जरूरी नहीं होता। अदालत निवास आदेश दे सकती है।'
    },
    {
      title: 'आप आर्थिक सहायता मांग सकती हैं',
      body: 'इलाज, आय का नुकसान, बच्चों का खर्च और भरण-पोषण मांगा जा सकता है। बिल, फोटो और मैसेज सुरक्षित रखें।'
    },
    {
      title: 'मुफ्त कानूनी मदद मिल सकती है',
      body: 'जिला विधिक सेवा प्राधिकरण और महिला हेल्पलाइन मुफ्त कानूनी सहायता से जोड़ सकते हैं।'
    }
  ]
};

const helpDirectory = [
  { name: 'Emergency Response Support System', type: 'Emergency', phone: '112', distance: 'Available across India' },
  { name: 'Women Helpline', type: 'Helpline', phone: '181', distance: 'State helpline' },
  { name: 'Police Women Helpline', type: 'Police', phone: '1091', distance: 'Many cities and states' },
  { name: 'National Commission for Women', type: 'Legal support', phone: '7827170170', distance: 'Remote complaint assistance' },
  { name: 'District Legal Services Authority', type: 'Legal aid', phone: 'Find via district court', distance: 'Nearest district' }
];

const AppContext = createContext<{
  language: Language;
  setLanguage: (language: Language) => void;
  isGuest: boolean;
  setIsGuest: (value: boolean) => void;
  pin: string | null;
  savePin: (value: string) => Promise<void>;
}>({
  language: 'en',
  setLanguage: () => undefined,
  isGuest: true,
  setIsGuest: () => undefined,
  pin: null,
  savePin: async () => undefined
});

function useApp() {
  return useContext(AppContext);
}

function QuickExitButton() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { language } = useApp();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={copy[language].quickExit}
      onPress={() => navigation.navigate('Neutral')}
      style={styles.quickExit}
    >
      <AppIcon name="exit-outline" size={18} color="#FFFFFF" />
      <Text style={styles.quickExitText}>{copy[language].quickExit}</Text>
    </Pressable>
  );
}

function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.topBar}>
        <View>
          <Text style={styles.brand}>Adhikaar Saathi</Text>
          <Text style={styles.brandSub}>Private support</Text>
        </View>
        <QuickExitButton />
      </View>
      {children}
    </SafeAreaView>
  );
}

function LanguagePicker({ selected, onSelect }: { selected: Language; onSelect: (language: Language) => void }) {
  return (
    <View style={styles.languageGrid}>
      {languageOptions.map((option) => {
        const isActive = selected === option.code;
        return (
          <Pressable
            key={option.code}
            accessibilityRole="button"
            accessibilityLabel={`Select ${option.englishName}`}
            style={[styles.languageButton, isActive && styles.languageButtonActive]}
            onPress={() => onSelect(option.code)}
          >
            <Text style={[styles.languageNative, isActive && styles.languageActiveText]}>{option.nativeName}</Text>
            <Text style={[styles.languageEnglish, isActive && styles.languageActiveText]}>{option.englishName}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function OnboardingScreen({ navigation }: { navigation: NativeStackNavigationProp<RootStackParamList, 'Onboarding'> }) {
  const { language, setLanguage, setIsGuest, savePin } = useApp();
  const t = copy[language];
  const [pinDraft, setPinDraft] = useState('');

  async function continueGuest() {
    setIsGuest(true);
    await AsyncStorage.setItem('hasOnboarded', 'true');
    navigation.replace('Main');
  }

  async function createPinAndContinue() {
    if (pinDraft.length < 4) {
      Alert.alert('Use at least 4 digits');
      return;
    }
    await savePin(pinDraft);
    setIsGuest(false);
    await AsyncStorage.setItem('hasOnboarded', 'true');
    navigation.replace('Main');
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.screenPad}>
        <View style={styles.onboardingHero}>
          <View style={styles.heroMark}>
            <AppIcon name="shield-checkmark" size={44} color={palette.teal} />
          </View>
          <Text style={styles.kicker}>Safety-first legal support</Text>
          <Text style={styles.heroTitle}>{t.appName}</Text>
          <Text style={styles.lead}>{t.strapline}</Text>
          <View style={styles.trustRow}>
            <Text style={styles.trustPill}>Guest mode</Text>
            <Text style={styles.trustPill}>PIN lock</Text>
            <Text style={styles.trustPill}>Quick Exit</Text>
          </View>
        </View>
        <Text style={styles.sectionTitle}>Choose language</Text>
        <LanguagePicker selected={language} onSelect={setLanguage} />
        <View style={styles.warningBand}>
          <AppIcon name="alert-circle" size={20} color={palette.rose} />
          <Text style={styles.warningText}>{t.danger}</Text>
        </View>
        <Pressable style={styles.primaryButton} onPress={continueGuest}>
          <AppIcon name="person-outline" size={20} color="#FFFFFF" />
          <Text style={styles.primaryButtonText}>{t.guest}</Text>
        </Pressable>
        <Text style={styles.sectionTitle}>{t.createPin}</Text>
        <TextInput
          secureTextEntry
          inputMode="numeric"
          maxLength={8}
          value={pinDraft}
          onChangeText={setPinDraft}
          placeholder="4-8 digits"
          style={styles.input}
        />
        <Pressable style={styles.secondaryButton} onPress={createPinAndContinue}>
          <AppIcon name="lock-closed-outline" size={19} color={palette.tealDark} />
          <Text style={styles.secondaryButtonText}>{t.createPin}</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

function HomeScreen() {
  const { language } = useApp();
  const t = copy[language];
  return (
    <AppShell>
      <ScrollView contentContainerStyle={styles.screenPad}>
        <View style={styles.homeHero}>
          <Text style={styles.homeKicker}>Protected demo workspace</Text>
          <Text style={styles.homeTitle}>{t.home}</Text>
          <View style={styles.trustRow}>
            <Text style={styles.trustPillDark}>Anonymous</Text>
            <Text style={styles.trustPillDark}>Local-first</Text>
          </View>
        </View>
        <View style={styles.warningBand}>
          <AppIcon name="call" size={20} color={palette.rose} />
          <Text style={styles.warningText}>{t.danger}</Text>
        </View>
        <View style={styles.grid}>
          <InfoTile icon="book-outline" title={t.rights} body="Plain-language rights and next steps." />
          <InfoTile icon="document-text-outline" title={t.report} body="Make a private incident note." />
          <InfoTile icon="folder-open-outline" title={t.evidence} body="Preserve evidence details locally." />
          <InfoTile icon="location-outline" title={t.help} body="Find helplines and legal aid." />
        </View>
      </ScrollView>
    </AppShell>
  );
}

function InfoTile({ icon, title, body }: { icon: IconName; title: string; body: string }) {
  return (
    <View style={styles.tile}>
      <View style={styles.tileIconRow}>
        <AppIcon name={icon} size={22} color={palette.teal} />
      </View>
      <View style={styles.tileText}>
        <Text style={styles.tileTitle}>{title}</Text>
        <Text style={styles.tileBody}>{body}</Text>
      </View>
    </View>
  );
}

function RightsScreen() {
  const { language } = useApp();
  const localizedRights = rightsContent[language] ?? rightsContent.en ?? [];
  return (
    <AppShell>
      <ScrollView contentContainerStyle={styles.screenPad}>
        <Text style={styles.h1}>{copy[language].rights}</Text>
        {!rightsContent[language] && (
          <View style={styles.noticeCard}>
            <Text style={styles.noticeText}>Curated legal-rights translations for this language are planned. For now, these rights are shown in simple English to avoid unsafe legal mistranslation.</Text>
          </View>
        )}
        {localizedRights.map((item) => (
          <View key={item.title} style={styles.card}>
            <Text style={styles.cardTitle}>{item.title}</Text>
            <Text style={styles.body}>{item.body}</Text>
          </View>
        ))}
      </ScrollView>
    </AppShell>
  );
}

function ReportScreen() {
  const { language } = useApp();
  const [reports, setReports] = useState<ReportRecord[]>([]);
  const [draft, setDraft] = useState({ place: '', description: '', immediateDanger: false, consentToShare: false });

  useEffect(() => {
    AsyncStorage.getItem('reports').then((value) => value && setReports(JSON.parse(value)));
  }, []);

  async function saveReport() {
    if (!draft.description.trim()) {
      Alert.alert('Add a short description');
      return;
    }
    const next: ReportRecord[] = [
      {
        id: String(Date.now()),
        date: new Date().toISOString(),
        place: draft.place,
        description: draft.description,
        immediateDanger: draft.immediateDanger,
        consentToShare: draft.consentToShare
      },
      ...reports
    ];
    setReports(next);
    setDraft({ place: '', description: '', immediateDanger: false, consentToShare: false });
    await AsyncStorage.setItem('reports', JSON.stringify(next));
    Alert.alert('Saved privately', 'This report is stored on this device for the Phase 1 demo.');
  }

  return (
    <AppShell>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.screenPad}>
          <Text style={styles.h1}>{copy[language].report}</Text>
          <Text style={styles.body}>Write only what feels safe. You can keep this on-device and choose later whether to share it.</Text>
          <TextInput style={styles.input} placeholder="Place or area" value={draft.place} onChangeText={(place) => setDraft({ ...draft, place })} />
          <TextInput
            style={[styles.input, styles.textArea]}
            multiline
            placeholder="What happened? Include date, time, people, injuries, threats, or witnesses."
            value={draft.description}
            onChangeText={(description) => setDraft({ ...draft, description })}
          />
          <ToggleRow
            label="I may be in immediate danger"
            value={draft.immediateDanger}
            onChange={(immediateDanger) => setDraft({ ...draft, immediateDanger })}
          />
          <ToggleRow
            label="I consent to share this later with a helper"
            value={draft.consentToShare}
            onChange={(consentToShare) => setDraft({ ...draft, consentToShare })}
          />
          <Pressable style={styles.primaryButton} onPress={saveReport}>
            <AppIcon name="save-outline" size={20} color="#FFFFFF" />
            <Text style={styles.primaryButtonText}>Save private report</Text>
          </Pressable>
          {reports.map((report) => (
            <View key={report.id} style={styles.card}>
              <Text style={styles.cardTitle}>{new Date(report.date).toLocaleString()}</Text>
              <Text style={styles.body}>{report.description}</Text>
            </View>
          ))}
        </ScrollView>
      </KeyboardAvoidingView>
    </AppShell>
  );
}

function EvidenceScreen() {
  const { language } = useApp();
  const [items, setItems] = useState<EvidenceRecord[]>([]);
  const [draft, setDraft] = useState({ label: '', kind: 'Photo', note: '' });

  useEffect(() => {
    AsyncStorage.getItem('evidence').then((value) => value && setItems(JSON.parse(value)));
  }, []);

  async function saveEvidence() {
    if (!draft.label.trim()) {
      Alert.alert('Add a label');
      return;
    }
    const next = [{ id: String(Date.now()), ...draft, createdAt: new Date().toISOString() }, ...items];
    setItems(next);
    setDraft({ label: '', kind: 'Photo', note: '' });
    await AsyncStorage.setItem('evidence', JSON.stringify(next));
  }

  return (
    <AppShell>
      <ScrollView contentContainerStyle={styles.screenPad}>
        <Text style={styles.h1}>{copy[language].evidence}</Text>
        <Text style={styles.body}>Phase 1 stores evidence notes only. Phase 2 adds encrypted S3-compatible file upload and chain-of-custody logs.</Text>
        <TextInput style={styles.input} placeholder="Evidence label" value={draft.label} onChangeText={(label) => setDraft({ ...draft, label })} />
        <View style={styles.segment}>
          {['Photo', 'Audio', 'Message'].map((kind) => (
            <Pressable key={kind} style={[styles.segmentButton, draft.kind === kind && styles.segmentActive]} onPress={() => setDraft({ ...draft, kind })}>
              <Text style={[styles.segmentText, draft.kind === kind && styles.segmentActiveText]}>{kind}</Text>
            </Pressable>
          ))}
        </View>
        <TextInput style={[styles.input, styles.textArea]} multiline placeholder="Where is it saved? Why does it matter?" value={draft.note} onChangeText={(note) => setDraft({ ...draft, note })} />
        <Pressable style={styles.primaryButton} onPress={saveEvidence}>
          <AppIcon name="add-circle-outline" size={20} color="#FFFFFF" />
          <Text style={styles.primaryButtonText}>Add evidence note</Text>
        </Pressable>
        {items.map((item) => (
          <View key={item.id} style={styles.card}>
            <Text style={styles.cardTitle}>{item.label}</Text>
            <Text style={styles.body}>{item.kind} · {new Date(item.createdAt).toLocaleDateString()}</Text>
            <Text style={styles.body}>{item.note}</Text>
          </View>
        ))}
      </ScrollView>
    </AppShell>
  );
}

function HelpScreen() {
  const { language } = useApp();
  return (
    <AppShell>
      <ScrollView contentContainerStyle={styles.screenPad}>
        <Text style={styles.h1}>{copy[language].help}</Text>
        <Text style={styles.body}>Nearby results are mocked for Phase 1. Use these public helplines for demo content.</Text>
        {helpDirectory.map((item) => (
          <View key={item.name} style={styles.card}>
            <Text style={styles.cardTitle}>{item.name}</Text>
            <Text style={styles.body}>{item.type} · {item.distance}</Text>
            <Text style={styles.phone}>{item.phone}</Text>
          </View>
        ))}
      </ScrollView>
    </AppShell>
  );
}

function GuidanceScreen() {
  const { language } = useApp();
  return (
    <AppShell>
      <ScrollView contentContainerStyle={styles.screenPad}>
        <Text style={styles.h1}>{copy[language].guidance}</Text>
        {[
          'Are you safe enough to continue using this phone?',
          'If no, use Quick Exit and call 112 from a safer place.',
          'If yes, write a short report and preserve messages, photos, medical slips, and witness names.',
          'Do not confront the abuser because of what you read here. Make a safety plan with someone you trust.'
        ].map((step, index) => (
          <View key={step} style={styles.stepRow}>
            <Text style={styles.stepNumber}>{index + 1}</Text>
            <Text style={styles.stepText}>{step}</Text>
          </View>
        ))}
      </ScrollView>
    </AppShell>
  );
}

function SettingsScreen() {
  const { language, setLanguage, isGuest, pin, savePin } = useApp();
  const [pinDraft, setPinDraft] = useState('');
  return (
    <AppShell>
      <ScrollView contentContainerStyle={styles.screenPad}>
        <Text style={styles.h1}>{copy[language].settings}</Text>
        <Text style={styles.body}>Mode: {isGuest ? 'Guest / anonymous' : 'PIN protected'}</Text>
        <Text style={styles.body}>App lock: {pin ? 'Enabled' : 'Not set'}</Text>
        <Text style={styles.sectionTitle}>Language</Text>
        <LanguagePicker selected={language} onSelect={setLanguage} />
        <Text style={styles.sectionTitle}>Change or add PIN</Text>
        <TextInput secureTextEntry inputMode="numeric" maxLength={8} style={styles.input} value={pinDraft} onChangeText={setPinDraft} placeholder="4-8 digits" />
        <Pressable
          style={styles.secondaryButton}
          onPress={async () => {
            if (pinDraft.length < 4) {
              Alert.alert('Use at least 4 digits');
              return;
            }
            await savePin(pinDraft);
            setPinDraft('');
            Alert.alert('PIN saved');
          }}
        >
          <AppIcon name="lock-closed-outline" size={19} color={palette.tealDark} />
          <Text style={styles.secondaryButtonText}>Save PIN</Text>
        </Pressable>
      </ScrollView>
    </AppShell>
  );
}

function LockedScreen({ route, navigation }: { route: { params: { next: keyof MainTabParamList } }; navigation: NativeStackNavigationProp<RootStackParamList, 'Locked'> }) {
  const { language, pin } = useApp();
  const [entry, setEntry] = useState('');
  async function tryBiometric() {
    if (Platform.OS === 'web') {
      Alert.alert('Use PIN in browser preview', 'Biometric unlock is available in native Android and iOS builds.');
      return;
    }
    const LocalAuthentication = await import('expo-local-authentication');
    const result = await LocalAuthentication.authenticateAsync({ promptMessage: copy[language].unlock });
    if (result.success) {
      navigation.replace('Main');
    }
  }
  function unlock() {
    if (!pin || entry === pin) {
      navigation.replace('Main');
      return;
    }
    Alert.alert('Incorrect PIN');
  }
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.screenPad}>
        <QuickExitButton />
        <Text style={styles.h1}>{copy[language].unlock}</Text>
        <Text style={styles.body}>Protected area: {route.params.next}</Text>
        <TextInput secureTextEntry inputMode="numeric" style={styles.input} value={entry} onChangeText={setEntry} placeholder={copy[language].pin} />
        <Pressable style={styles.primaryButton} onPress={unlock}>
          <AppIcon name="key-outline" size={20} color="#FFFFFF" />
          <Text style={styles.primaryButtonText}>Unlock</Text>
        </Pressable>
        <Pressable style={styles.secondaryButton} onPress={tryBiometric}>
          <AppIcon name="finger-print-outline" size={19} color={palette.tealDark} />
          <Text style={styles.secondaryButtonText}>{copy[language].useBiometric}</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

function NeutralScreen() {
  const [display, setDisplay] = useState('0');
  const keys = ['7', '8', '9', '4', '5', '6', '1', '2', '3', '0', '.', 'C'];
  useEffect(() => {
    if (Platform.OS === 'android') {
      BackHandler.exitApp();
    }
  }, []);
  return (
    <SafeAreaView style={styles.safeNeutral}>
      <View style={styles.calculator}>
        <Text style={styles.calcTitle}>Calculator</Text>
        <Text style={styles.calcDisplay}>{display}</Text>
        <View style={styles.calcGrid}>
          {keys.map((key) => (
            <Pressable key={key} style={styles.calcKey} onPress={() => setDisplay(key === 'C' ? '0' : display === '0' ? key : display + key)}>
              <Text style={styles.calcKeyText}>{key}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    </SafeAreaView>
  );
}

function ToggleRow({ label, value, onChange }: { label: string; value: boolean; onChange: (next: boolean) => void }) {
  return (
    <Pressable style={styles.toggleRow} onPress={() => onChange(!value)}>
      <Text style={styles.toggleLabel}>{label}</Text>
      <View style={[styles.toggleTrack, value && styles.toggleTrackOn]}>
        <View style={[styles.toggleKnob, value && styles.toggleKnobOn]} />
      </View>
    </Pressable>
  );
}

function MainTabs() {
  const { language, pin } = useApp();
  const sensitive: Array<keyof MainTabParamList> = ['Report', 'Evidence', 'Guidance'];
  return (
    <Tabs.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: palette.teal,
        tabBarInactiveTintColor: palette.muted,
        tabBarStyle: { minHeight: 64, paddingTop: 6 },
        tabBarIcon: ({ color, size }) => {
          const icons: Record<keyof MainTabParamList, IconName> = {
            Home: 'home-outline',
            Rights: 'book-outline',
            Report: 'document-text-outline',
            Evidence: 'folder-open-outline',
            Help: 'location-outline',
            Guidance: 'chatbubbles-outline',
            Settings: 'settings-outline'
          };
          return <AppIcon name={icons[route.name as keyof MainTabParamList]} size={size} color={color} />;
        }
      })}
    >
      <Tabs.Screen name="Home" component={HomeScreen} options={{ title: copy[language].home }} />
      <Tabs.Screen name="Rights" component={RightsScreen} options={{ title: copy[language].rights }} />
      <Tabs.Screen
        name="Report"
        component={ReportScreen}
        options={{ title: copy[language].report }}
        listeners={({ navigation }) => ({
          tabPress: (event) => {
            if (pin && sensitive.includes('Report')) {
              event.preventDefault();
              navigation.getParent()?.navigate('Locked', { next: 'Report' });
            }
          }
        })}
      />
      <Tabs.Screen
        name="Evidence"
        component={EvidenceScreen}
        options={{ title: copy[language].evidence }}
        listeners={({ navigation }) => ({
          tabPress: (event) => {
            if (pin && sensitive.includes('Evidence')) {
              event.preventDefault();
              navigation.getParent()?.navigate('Locked', { next: 'Evidence' });
            }
          }
        })}
      />
      <Tabs.Screen name="Help" component={HelpScreen} options={{ title: copy[language].help }} />
      <Tabs.Screen
        name="Guidance"
        component={GuidanceScreen}
        options={{ title: copy[language].guidance }}
        listeners={({ navigation }) => ({
          tabPress: (event) => {
            if (pin && sensitive.includes('Guidance')) {
              event.preventDefault();
              navigation.getParent()?.navigate('Locked', { next: 'Guidance' });
            }
          }
        })}
      />
      <Tabs.Screen name="Settings" component={SettingsScreen} options={{ title: copy[language].settings }} />
    </Tabs.Navigator>
  );
}

export default function App() {
  const [language, setLanguageState] = useState<Language>('en');
  const [isGuest, setIsGuestState] = useState(true);
  const [pin, setPin] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [hasOnboarded, setHasOnboarded] = useState(false);

  useEffect(() => {
    Promise.all([
      AsyncStorage.getItem('language'),
      AsyncStorage.getItem('pin'),
      AsyncStorage.getItem('isGuest'),
      AsyncStorage.getItem('hasOnboarded')
    ]).then(([storedLanguage, storedPin, storedGuest, onboarded]) => {
      if (isLanguage(storedLanguage)) {
        setLanguageState(storedLanguage);
      }
      setPin(storedPin);
      setIsGuestState(storedGuest !== 'false');
      setHasOnboarded(onboarded === 'true');
      setReady(true);
    });
  }, []);

  const contextValue = useMemo(
    () => ({
      language,
      setLanguage: (next: Language) => {
        setLanguageState(next);
        AsyncStorage.setItem('language', next);
      },
      isGuest,
      setIsGuest: (value: boolean) => {
        setIsGuestState(value);
        AsyncStorage.setItem('isGuest', String(value));
      },
      pin,
      savePin: async (value: string) => {
        setPin(value);
        await AsyncStorage.setItem('pin', value);
      }
    }),
    [language, isGuest, pin]
  );

  if (!ready) {
    return (
      <SafeAreaProvider>
        <SafeAreaView style={styles.safe}>
          <Text style={styles.loading}>Adhikaar Saathi</Text>
        </SafeAreaView>
      </SafeAreaProvider>
    );
  }

  return (
    <AppContext.Provider value={contextValue}>
      <SafeAreaProvider>
        <NavigationContainer>
          <StatusBar style="dark" />
          <RootStack.Navigator screenOptions={{ headerShown: false }} initialRouteName={hasOnboarded ? 'Main' : 'Onboarding'}>
            <RootStack.Screen name="Onboarding" component={OnboardingScreen} />
            <RootStack.Screen name="Main" component={MainTabs} />
            <RootStack.Screen name="Neutral" component={NeutralScreen} />
            <RootStack.Screen name="Locked" component={LockedScreen} />
          </RootStack.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </AppContext.Provider>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  safe: { flex: 1, backgroundColor: palette.paper },
  safeNeutral: { flex: 1, backgroundColor: '#F1F3F6' },
  screenPad: { width: '100%', maxWidth: 560, alignSelf: 'center', padding: 20, paddingBottom: 28, gap: 16 },
  topBar: {
    minHeight: 68,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: palette.line,
    backgroundColor: 'rgba(255,255,255,0.96)'
  },
  brand: { color: palette.ink, fontWeight: '900', fontSize: 18 },
  brandSub: { color: palette.muted, fontWeight: '700', fontSize: 11, marginTop: 1 },
  quickExit: {
    minHeight: 42,
    flexDirection: 'row',
    gap: 7,
    alignItems: 'center',
    backgroundColor: palette.rose,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8
  },
  quickExitText: { color: '#FFFFFF', fontWeight: '800', fontSize: 13 },
  iconBadge: { borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  onboardingHero: {
    backgroundColor: palette.panel,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: palette.line,
    padding: 20,
    gap: 12,
    shadowColor: '#1A2A3A',
    shadowOpacity: 0.08,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 8 },
    elevation: 3
  },
  heroMark: {
    width: 82,
    height: 82,
    borderRadius: 8,
    backgroundColor: palette.softTeal,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#BFE8E4'
  },
  kicker: { color: palette.tealDark, fontSize: 12, fontWeight: '900', textTransform: 'uppercase' },
  heroTitle: { fontSize: 36, lineHeight: 42, color: palette.ink, fontWeight: '900' },
  h1: { fontSize: 28, lineHeight: 35, color: palette.ink, fontWeight: '900' },
  lead: { fontSize: 17, lineHeight: 25, color: palette.muted },
  body: { fontSize: 15, lineHeight: 22, color: palette.muted },
  loading: { margin: 24, fontSize: 22, fontWeight: '900', color: palette.teal },
  trustRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 2 },
  trustPill: {
    color: palette.tealDark,
    backgroundColor: palette.softTeal,
    borderRadius: 8,
    overflow: 'hidden',
    paddingVertical: 7,
    paddingHorizontal: 10,
    fontSize: 12,
    fontWeight: '900'
  },
  trustPillDark: {
    color: '#FFFFFF',
    backgroundColor: 'rgba(255,255,255,0.18)',
    borderRadius: 8,
    overflow: 'hidden',
    paddingVertical: 7,
    paddingHorizontal: 10,
    fontSize: 12,
    fontWeight: '900'
  },
  homeHero: {
    backgroundColor: palette.tealDark,
    borderRadius: 8,
    padding: 18,
    gap: 9,
    borderWidth: 1,
    borderColor: '#0F7577'
  },
  homeKicker: { color: '#BDEDE9', fontSize: 12, fontWeight: '900', textTransform: 'uppercase' },
  homeTitle: { color: '#FFFFFF', fontSize: 28, lineHeight: 35, fontWeight: '900' },
  homeLead: { color: '#D7F1EE', fontSize: 16, lineHeight: 24 },
  warningBand: { flexDirection: 'row', gap: 10, padding: 14, borderRadius: 8, backgroundColor: palette.softRose, borderWidth: 1, borderColor: '#F3C5D0' },
  warningText: { flex: 1, color: palette.ink, fontSize: 15, lineHeight: 21, fontWeight: '600' },
  primaryButton: {
    minHeight: 54,
    borderRadius: 8,
    backgroundColor: palette.teal,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    shadowColor: palette.tealDark,
    shadowOpacity: 0.18,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 2
  },
  primaryButtonText: { color: '#FFFFFF', fontWeight: '800', fontSize: 16 },
  secondaryButton: { minHeight: 52, borderRadius: 8, borderWidth: 1, borderColor: '#A8DCD7', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, paddingHorizontal: 16, backgroundColor: palette.softTeal },
  secondaryButtonText: { color: palette.tealDark, fontWeight: '800', fontSize: 15 },
  sectionTitle: { color: palette.ink, fontSize: 16, fontWeight: '800', marginTop: 4 },
  input: {
    minHeight: 52,
    borderWidth: 1,
    borderColor: palette.line,
    backgroundColor: palette.panel,
    borderRadius: 8,
    paddingHorizontal: 14,
    color: palette.ink,
    fontSize: 16
  },
  textArea: { minHeight: 120, textAlignVertical: 'top', paddingTop: 14 },
  segment: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  segmentButton: { flex: 1, minWidth: 92, borderRadius: 8, borderWidth: 1, borderColor: palette.line, paddingVertical: 12, paddingHorizontal: 12, alignItems: 'center', backgroundColor: palette.panel },
  segmentActive: { backgroundColor: palette.teal, borderColor: palette.teal },
  segmentText: { color: palette.muted, fontWeight: '700' },
  segmentActiveText: { color: '#FFFFFF' },
  languageGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  languageButton: {
    width: '31.5%',
    minWidth: 98,
    minHeight: 62,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: palette.line,
    backgroundColor: palette.panel,
    paddingVertical: 9,
    paddingHorizontal: 8,
    justifyContent: 'center',
    gap: 3
  },
  languageButtonActive: { backgroundColor: palette.teal, borderColor: palette.teal },
  languageNative: { color: palette.ink, fontSize: 14, lineHeight: 18, fontWeight: '900', textAlign: 'center' },
  languageEnglish: { color: palette.muted, fontSize: 10, lineHeight: 13, fontWeight: '800', textAlign: 'center' },
  languageActiveText: { color: '#FFFFFF' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  tile: {
    width: '47%',
    minHeight: 150,
    backgroundColor: palette.panel,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 8,
    padding: 14,
    gap: 10,
    shadowColor: '#1A2A3A',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 1
  },
  tileIconRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  tileText: { gap: 5 },
  tileTitle: { color: palette.ink, fontSize: 16, fontWeight: '900' },
  tileBody: { color: palette.muted, fontSize: 13, lineHeight: 19 },
  card: {
    backgroundColor: palette.panel,
    borderWidth: 1,
    borderColor: palette.line,
    borderRadius: 8,
    padding: 16,
    gap: 8,
    shadowColor: '#1A2A3A',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 1
  },
  noticeCard: { backgroundColor: palette.softAmber, borderWidth: 1, borderColor: '#F1D6A8', borderRadius: 8, padding: 13 },
  noticeText: { color: '#5E461E', fontSize: 13, lineHeight: 19, fontWeight: '700' },
  cardTitle: { color: palette.ink, fontSize: 17, lineHeight: 22, fontWeight: '900' },
  phone: { color: palette.tealDark, fontSize: 18, fontWeight: '900' },
  toggleRow: { minHeight: 56, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12, backgroundColor: palette.panel, borderWidth: 1, borderColor: palette.line, borderRadius: 8, paddingHorizontal: 14 },
  toggleLabel: { flex: 1, color: palette.ink, fontSize: 15, fontWeight: '700' },
  toggleTrack: { width: 50, height: 30, borderRadius: 15, backgroundColor: '#B8B8B8', padding: 3 },
  toggleTrackOn: { backgroundColor: palette.green },
  toggleKnob: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#FFFFFF' },
  toggleKnobOn: { transform: [{ translateX: 20 }] },
  stepRow: { flexDirection: 'row', gap: 12, alignItems: 'flex-start', backgroundColor: palette.panel, borderWidth: 1, borderColor: palette.line, borderRadius: 8, padding: 14 },
  stepNumber: { width: 30, height: 30, borderRadius: 15, backgroundColor: palette.saffron, color: '#FFFFFF', textAlign: 'center', lineHeight: 30, fontWeight: '900' },
  stepText: { flex: 1, color: palette.ink, fontSize: 15, lineHeight: 22, fontWeight: '600' },
  calculator: { flex: 1, justifyContent: 'flex-end', padding: 20, gap: 16 },
  calcTitle: { color: '#4D4D4D', fontSize: 18, fontWeight: '700' },
  calcDisplay: { minHeight: 88, color: '#151515', fontSize: 42, fontWeight: '300', textAlign: 'right', padding: 14, backgroundColor: '#FFFFFF', borderRadius: 8 },
  calcGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  calcKey: { width: '30.7%', aspectRatio: 1.6, backgroundColor: '#FFFFFF', borderRadius: 8, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#DDDDDD' },
  calcKeyText: { fontSize: 24, color: '#222222', fontWeight: '500' }
});
