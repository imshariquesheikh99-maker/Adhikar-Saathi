# Adhikaar Saathi Handoff

## Running Now

- Mobile web preview: http://localhost:8082
- API health: http://localhost:4000/health

## Main Project Areas

- `apps/mobile`: React Native 0.73 / Expo Phase 1 mobile MVP.
- `services/api`: Node.js / Express Phase 1 REST API skeleton.
- `docs/phase-plan.md`: 24-week MCA capstone plan with Phase 1 and Phase 2 split.
- `README.md`: setup, scope, and safety UX summary.

## Verified

- `npm run typecheck -w apps/mobile`
- `npm run lint -w apps/mobile`
- `npm run typecheck -w services/api`
- `npm run lint -w services/api`
- `npx expo export --platform web`
- `curl -s http://localhost:4000/health`
- `curl -I http://localhost:8082`

## Note

The live `expo start --web` CLI hits a `freeport-async` port scanning issue under the desktop environment's Node 26 runtime. The app bundle exports successfully, and the exported web build is served for preview on port 8082. For Android-first development, use Node 20 LTS as specified in the capstone stack.
